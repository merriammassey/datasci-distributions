from setuptools import setup

setup(name='datasci_distributions',
      version='1.1',
      description='Gaussian and Binomial distributions',
      packages=['datasci_distributions'],
      zip_safe=False)
